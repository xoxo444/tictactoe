
#include <stdio.h>

char board[3][3];
char currentplayer = 'X';

void initializeboard() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = ' ';
}

void printboard() {
    printf("\n");
    for (int i = 0; i < 3; i++) {
        printf(" %c | %c | %c ", board[i][0], board[i][1], board[i][2]);
        if (i != 2) printf("\n---|---|---\n");
    }
    printf("\n\n");
}

int iswinner() {
    for (int i = 0; i < 3; i++) {
        if ((board[i][0] == currentplayer && board[i][1] == currentplayer && board[i][2] == currentplayer) ||
            (board[0][i] == currentplayer && board[1][i] == currentplayer && board[2][i] == currentplayer))
            return 1;
    }

    if ((board[0][0] == currentplayer && board[1][1] == currentplayer && board[2][2] == currentplayer) ||
        (board[0][2] == currentplayer && board[1][1] == currentplayer && board[2][0] == currentplayer))
        return 1;

    return 0;
}

int isDraw() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == ' ')
                return 0;
    return 1;
}

void switchplayer() {
    currentplayer = (currentplayer == 'X') ? 'O' : 'X';
}

void playGame() {
    int row, col;
    while (1) {
        printboard();
        printf("Player %c, enter row and column (0-2): ", currentplayer);
        scanf("%d%d", &row, &col);

        if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            printf("Invalid move! Try again.\n");
            continue;
        }

        board[row][col] = currentplayer;

        if (iswinner()) {
            printboard();
            printf("🎉 Player %c wins!\n", currentplayer);
            break;
        }

        if (isDraw()) {
            printboard();
            printf("It's a draw!\n");
            break;
        }

        switchplayer();
    }
}

int main() {
    initializeboard();
    playGame();
    return 0;
}
